BASIC INFO
==========
- THIS MODULE IS NOT STABLE FOR USAGE.  USE AT YOUR OWN RISK.
- Provides failover feature.
- Works with Cloud, Cluster and Scripting module.


DIRECTORY STRUCTURE
===================

cloud
  +-modules (depends on Cloud module)(Cloud is a core module for Cloud package)
    +-cloud_activity_audit
    +-cloud_alerts
    x-cloud_auto_scaling
    +-cloud_billing
    +-cloud_cluster
    +-cloud_dashboard
    o-cloud_failover
    +-cloud_inputs
    +-cloud_metering
    +-cloud_monitoring
    +-cloud_pricing
    +-cloud_resource_allocator
    x-cloud_scaling_manager
    +-cloud_scripting
    +-cloud_server_templates
 
    x... Not released yet.

 
CHANGE HISTORY
==============
2011/12/21 ver.1.2  released 6.x-1.2

Copyright
=========

Copyright (c) 2012 DOCOMO Innovations, Inc.

End of README.txt