Entity iframe theme

A slightly modified version of Drupal 7's core Stark theme.
This provides an incredibly basic iframe mode for sites that
has been optimized for use with entity_iframe, though it is
not required.